package com.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.bean.User;
import com.ssm.mapper.UserMapper;

/**
 * 用户信息Service
 */
@Service
public class UserService{

	@Autowired
    private UserMapper userMapper;
    
	public User get(Integer id) {
		return userMapper.get(id);
	}
	
	public List<User> findList(User user) {
		return userMapper.findList(user);
	}
	
	public void save(User user) {
		if(user.getId() == null || user.getId() == 0) {
    		userMapper.insert(user);
    	} else {
    		userMapper.update(user);
    	}
	}
	
	public int delete(String id) {
		return userMapper.delete(id);
	}
	
	public User identity(String name, String password, String auth) {
    	List<User> list = userMapper.identity(name, password, auth);
    	if(list != null && !list.isEmpty()) {
    		return list.get(0);
    	}
    	return new User();
    }
}