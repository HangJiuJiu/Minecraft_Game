package com.ssm.controller;

import com.ssm.bean.Game;
import com.ssm.bean.GameVo;
import com.ssm.bean.User;
import com.ssm.service.MaterialService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping(value = "/ssm/material")
public class MaterialController {
    @Autowired
    private MaterialService materialService;


    @RequestMapping(value = "/list")
    public ModelAndView list(GameVo game, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView("materialPage");
        User user = (User) request.getSession().getAttribute("currentUser");
        int pageNo = game.getPageNo();
        int count = (materialService.countAll() / game.getPageSize()) + 1;

        if (pageNo <= 0) {
            pageNo = 1;
        }
        if (pageNo > count) {
            pageNo = count;
        }
        int pageSun = (pageNo - 1) * game.getPageSize();
        game.setPageNo(pageSun);
        if ("1".equals(user.getAuth())) {
            game.setState("1");
        }
        List<Game> datalist = materialService.findList(game);
        game.setPageNo(pageNo);
        mv.addObject("datalist", datalist)
                .addObject("param", game)
                .addObject("pages", count);
        return mv;
    }


    @RequestMapping(value = "form")
    public ModelAndView form(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("materialForm");
        String id = request.getParameter("id");
        Game game = new Game();
        if (StringUtils.isNotBlank(id)) {
            game = materialService.get(id);
        }
        mv.addObject("game", game);
        return mv;
    }


    @RequestMapping(value = "save")
    public String save(HttpServletRequest request, Game game) {
        User user = (User) request.getSession().getAttribute("currentUser");
        materialService.save(game, user);
        if (game.getId() == null || game.getId() == 0) {
            return "redirect:/ssm/material/index";
        }
        return "redirect:/ssm/material/list";
    }


    @RequestMapping(value = "delete")
    public String delete(HttpServletRequest request) {
        materialService.delete(request.getParameter("id"));
        return "redirect:/ssm/material/list";
    }


    @RequestMapping(value = "view")
    public ModelAndView view(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("materialView");
        String id = request.getParameter("id");
        Game game = materialService.get(id);
        mv.addObject("game", game);
        return mv;
    }


    @RequestMapping(value = "updateState")
    public String updateState(HttpServletRequest request) {
        Game game = materialService.get(request.getParameter("id"));
        game.setState(request.getParameter("state"));
        materialService.save(game, new User());
        return "redirect:/ssm/material/list";
    }

    @RequestMapping(value = "/index")
    public ModelAndView index(GameVo game, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView("materialIndex");
        User user = (User) request.getSession().getAttribute("currentUser");
        game.setCreateid(user.getId());
        List<Game> datalist = materialService.findList(game);
        mv.addObject("datalist", datalist).addObject("param", game);
        return mv;
    }
}
