package com.ssm.controller;

import com.ssm.bean.Collect;
import com.ssm.bean.User;
import com.ssm.service.CollectService;
import com.ssm.util.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 我的收藏Controller
 */
@Controller
@RequestMapping(value = "/ssm/collect")
public class CollectController {

    // 注入spring容器中的bean
    //让我们可以直接使用 不用去new对象
    @Autowired
    private CollectService collectService;

    /**
     * 1、使用@RequestMapping注解来映射请求的URL
     * 2、使用ModelAndView类用来存储处理完后的结果数据，以及显示该数据的视图。
     * 3、collect为查询参数
     */
    /**
     * @param collect  我的收藏类
     * @param request  http请求信息
     * @param response http响应信息
     * @return ModelAndView 视图与模型封装类 用于携带数据并跳转指定的页面
     */
    @RequestMapping(value = "/list")
    public ModelAndView list(Collect collect, HttpServletRequest request, HttpServletResponse response) {
        // ModelAndView构造方法可以指定返回的页面名称-collectPage
        ModelAndView mv = new ModelAndView("collectPage");
        // 从session中获取当前登录的用户信息
        User user = (User) request.getSession().getAttribute("currentUser");
        collect.setUserid(user.getId());
        // 通过调取service获取我的收藏列表
        List<Collect> datalist = collectService.findList(collect);
        // 使用addObject()设置需要返回的值
        mv.addObject("datalist", datalist).addObject("param", collect);
        // 让该ModelAndView返回Spring MVC框架去处理
        return mv;
    }

    /**
     * 跳转新增/修改页面
     */
    @RequestMapping(value = "form")
    public ModelAndView form(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("collectForm");
        // 获取请求中的参数
        String id = request.getParameter("id");
        Collect collect = new Collect();
        // 如果id不为空，则获取我的收藏，从而进行修改
        if (StringUtils.isNotBlank(id)) {
            collect = collectService.get(id);
        }
        mv.addObject("collect", collect);
        return mv;
    }

    /**
     * 新增或修改 我的收藏
     *
     * @param request
     * @param collect 接受前端提交过来的收藏信息
     * @return
     */
    @RequestMapping(value = "save")
    public String save(HttpServletRequest request, Collect collect) {
        // 从session中获取当前登录的用户信息
        User user = (User) request.getSession().getAttribute("currentUser");
        // 向收藏类中 设置用户的id 以及收藏的时间
        collect.setUserid(user.getId());
        collect.setTime(DateUtils.getDateTime());
        // 调用service层执行保存方法
        collectService.save(collect);
        // 从定向到指定页面
        return "redirect:/ssm/collect/list";
    }

    /**
     * 删除
     */
    @RequestMapping(value = "delete")
    public String delete(HttpServletRequest request) {
        // 调用service层的删除方法
        collectService.delete(request.getParameter("id"));
        return "redirect:/ssm/collect/list";
    }

}