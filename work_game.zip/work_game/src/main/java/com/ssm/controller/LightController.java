package com.ssm.controller;

import com.ssm.bean.Game;
import com.ssm.bean.GameVo;
import com.ssm.bean.User;
import com.ssm.service.LightService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping(value = "/ssm/light")
public class LightController {
    @Autowired
    private LightService lightService;

    @RequestMapping(value = "/list")
    public ModelAndView list(GameVo game, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView("lightPage");
        User user = (User) request.getSession().getAttribute("currentUser");
        int pageNo = game.getPageNo();
        int count = (lightService.countAll() / game.getPageSize()) + 1;

        if (pageNo <= 0) {
            pageNo = 1;
        }
        if (pageNo > count) {
            pageNo = count;
        }
        int pageSun = (pageNo - 1) * game.getPageSize();
        game.setPageNo(pageSun);
        if ("1".equals(user.getAuth())) {
            game.setState("1");
        }
        List<Game> datalist = lightService.findList(game);
        game.setPageNo(pageNo);
        mv.addObject("datalist", datalist)
                .addObject("param", game)
                .addObject("pages", count);
        return mv;
    }

    /**
     * 跳转新增/修改页面
     */
    @RequestMapping(value = "form")
    public ModelAndView form(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("lightForm");
        String id = request.getParameter("id");
        Game game = new Game();
        if (StringUtils.isNotBlank(id)) {
            game = lightService.get(id);
        }
        mv.addObject("game", game);
        return mv;
    }

    /**
     * 新增/修改
     */
    @RequestMapping(value = "save")
    public String save(HttpServletRequest request, Game game) {
        User user = (User) request.getSession().getAttribute("currentUser");
        lightService.save(game, user);
        if (game.getId() == null || game.getId() == 0) {
            return "redirect:/ssm/light/index";
        }
        return "redirect:/ssm/light/list";
    }

    /**
     * 删除
     */
    @RequestMapping(value = "delete")
    public String delete(HttpServletRequest request) {
        lightService.delete(request.getParameter("id"));
        return "redirect:/ssm/light/list";
    }

    /**
     * 跳转审核页面
     */
    @RequestMapping(value = "view")
    public ModelAndView view(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("lightView");
        String id = request.getParameter("id");
        Game game = lightService.get(id);
        mv.addObject("game", game);
        return mv;
    }

    /**
     * 审核
     */
    @RequestMapping(value = "updateState")
    public String updateState(HttpServletRequest request) {
        Game game = lightService.get(request.getParameter("id"));
        game.setState(request.getParameter("state"));
        lightService.save(game, new User());
        return "redirect:/ssm/light/list";
    }

    /**
     * 我的模组
     */
    @RequestMapping(value = "/index")
    public ModelAndView index(GameVo game, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView("lightIndex");
        User user = (User) request.getSession().getAttribute("currentUser");
        game.setCreateid(user.getId());
        List<Game> datalist = lightService.findList(game);
        mv.addObject("datalist", datalist).addObject("param", game);
        return mv;
    }
}
